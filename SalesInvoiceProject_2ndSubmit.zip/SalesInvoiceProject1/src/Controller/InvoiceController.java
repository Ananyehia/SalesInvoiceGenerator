package Controller;
import Model.FileOperations;
import Model.InvoiceHeader;
import Model.InvoiceLines;
import View.MyFrame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;

public class InvoiceController {
public MyFrame view;
public List<InvoiceHeader> model;

public FileOperations FileOps;

    public InvoiceController() {

    }

    public InvoiceController(MyFrame view){
    this.view = view;
    view.l= this;
    this.FileOps = new FileOperations();
    //this.model = FileOps.loadFile(view);




}

    private void LoadDetails()
    {

        try
        {
            DefaultTableModel table = new DefaultTableModel();
            view.InvDetails.setModel(table);
            table.setColumnIdentifiers(new String [] {
                    "No.", "Item Name", "Item Price", "Count", "Item Total"
            });

            // Calculate Invoice Total Field
            int InvoiceTotal = 0;
            String InvoiceId = view.InvTab.getValueAt(view.InvTab.getSelectedRow(),0).toString();
            for(int i = 0;i< model.size();i++)
            {

                    if(model.get(i).Lines.get(0).getInvoiceNum().equals(InvoiceId))
                    {
                        for(int j = 0;j< model.get(i).Lines.size();j++)
                        {
                            InvoiceTotal+= Integer.parseInt(model.get(i).Lines.get(j).gettotal());
                            table.addRow(new String[]{
                                            model.get(i).Lines.get(j).getInvoiceNum(),
                                            model.get(i).Lines.get(j).getItemName(),
                                            model.get(i).Lines.get(j).getItemPrice(),
                                            model.get(i).Lines.get(j).getCount(),
                                            model.get(i).Lines.get(j).gettotal()
                            });
                        }

                    }



            }
            //take the invoice no. to Display
            table.addRow(new String []{InvoiceId,"","","",""});
            view.jLabel7.setText(InvoiceId);
            view.jLabel8.setText(String.valueOf(InvoiceTotal));
            view.InvoiceDate.setText(view.InvTab.getValueAt(view.InvTab.getSelectedRow(),1).toString());
            view.customerName.setText(view.InvTab.getValueAt(view.InvTab.getSelectedRow(),2).toString());

            //Update the Invoice total on the screen
            DefaultTableModel newmodel = (DefaultTableModel)view.InvTab.getModel();
            newmodel.setValueAt(String.valueOf(InvoiceTotal),view.InvTab.getSelectedRow(),3);

        }
        catch (Exception e) {
            view.jLabel7.setText(" ");
            view.jLabel8.setText(" ");
            view.InvoiceDate.setText(" ");
            view.customerName.setText(" ");
        }

    }

    private void createInvoice()
    {
        DefaultTableModel table = (DefaultTableModel)view.InvTab.getModel();

        int NewId = Integer.parseInt(table.getValueAt(table.getRowCount()-1,0).toString()) +1;
        table.addRow(new String[]{String.valueOf(NewId),"","",""});

        InvoiceHeader Invoice = new InvoiceHeader();
        Invoice.setInvoiceNum(String.valueOf(NewId));
        Invoice.Lines.add(new InvoiceLines(String.valueOf(NewId),"","",""));
        model.add(Invoice);

        view.InvTab.setRowSelectionInterval(table.getRowCount()-1,table.getRowCount()-1);
        LoadDetails();
        //DefaultTableModel Detailmodel = (DefaultTableModel)view.InvDetails.getModel();
        //Detailmodel.addRow(new String[]{String.valueOf(NewId),"","","",""});

    }

    private void deleteInvoice(){
        DefaultTableModel table = (DefaultTableModel)view.InvTab.getModel();

        //remove the invoice from the model
        String InvoiceId = table.getValueAt(view.InvTab.getSelectedRow(),0).toString();
        for(int i =0 ; i< model.size();i++)
        {
            if(model.get(i).getInvoiceNum().equals(InvoiceId))
            {
                model.remove(i);
            }
        }

        //remove the row from the view
        table.removeRow(view.InvTab.getSelectedRow());

        //Mark First row as selected
        view.InvTab.setRowSelectionInterval(0,0);
        LoadDetails();

    }

    private void  cancelChanges(){
        LoadDetails();
    }

    private void saveChanges(){


        if(view.customerName.getText().isEmpty() || view.InvoiceDate.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(view,"Please Fill the empty Fields First ","ERROR",JOptionPane.ERROR_MESSAGE);

        }
        else {

            DefaultTableModel table = (DefaultTableModel) view.InvDetails.getModel();
            int InvoiceTotal = 0;
            for (int i = 0; i < model.size(); i++) {
                if (model.get(i).getInvoiceNum().equals(view.jLabel7.getText())) {

                    model.get(i).setInvoiceDate(view.InvoiceDate.getText());
                    model.get(i).setCustomerName(view.customerName.getText());
                    List<InvoiceLines> Lines = new ArrayList<InvoiceLines>();
                    for (int j = 0; j < table.getRowCount(); j++) {
                        if (table.getValueAt(j, 1).toString().isEmpty()) {
                            break;
                        }
                        InvoiceLines Line = new InvoiceLines();
                        Line.setInvoiceNum(table.getValueAt(j, 0).toString());
                        Line.setItemName(table.getValueAt(j, 1).toString());
                        Line.setItemPrice(table.getValueAt(j, 2).toString());
                        Line.setCount(table.getValueAt(j, 3).toString());
                        int num1 = Integer.parseInt(table.getValueAt(j, 2).toString());
                        int num2 = Integer.parseInt(table.getValueAt(j, 3).toString());
                        int total = num1 * num2;
                        InvoiceTotal += total;
                        Lines.add(Line);
                    }
                    model.get(i).setInvoiceTotal(String.valueOf(InvoiceTotal));
                    model.get(i).Lines = (ArrayList<InvoiceLines>) Lines;
                }
            }

            DefaultTableModel newmodel = (DefaultTableModel) view.InvTab.getModel();
            newmodel.setValueAt(String.valueOf(InvoiceTotal), view.InvTab.getSelectedRow(), 3);
            newmodel.setValueAt(view.customerName.getText(), view.InvTab.getSelectedRow(), 2);
            newmodel.setValueAt(view.InvoiceDate.getText(), view.InvTab.getSelectedRow(), 1);
            LoadDetails();
        }

    }


    private void Exception() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    public void Add_LineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_LineActionPerformed
        DefaultTableModel Detailmodel = (DefaultTableModel)view.InvDetails.getModel();
        Detailmodel.addRow(new String[]{Detailmodel.getValueAt(0, 0).toString(),"","","",""});
    }//GEN-LAST:event_Add_LineActionPerformed

    public void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       //Disable editing in the view form
        view.InvTab.setDefaultEditor(Object.class, null);

        //Load the Invoice header File to the model
        try
        {
            model = FileOps.loadFile("InvoiceHeader.csv");
        }
        catch (Exception e) {
            if (e.getMessage().equals("Wrong Date Format"))
            {
                JOptionPane.showMessageDialog(view,"Wrong Date Format\n Please Choose another File ","ERROR",JOptionPane.ERROR_MESSAGE);
            }
            else if(e.getClass() == FileNotFoundException.class)
            {
                JOptionPane.showMessageDialog(view,"File Not Found\n Please make sure file exists in project directory ","ERROR",JOptionPane.ERROR_MESSAGE);

            }
            else {
                JOptionPane.showMessageDialog(view,"File Format is not Supported\n Please Choose another File ","ERROR",JOptionPane.ERROR_MESSAGE);
            }
        }

        //update the table view
        DefaultTableModel table = new DefaultTableModel();
        view.InvTab.setModel(table);
        table.setColumnIdentifiers(new String [] {
                "No.", "Date", "Customer", "Total"
        });
        for(int i = 0;i < model.size();i++)
        {table.addRow(new String[]{model.get(i).getInvoiceNum(),
                model.get(i).getInvoiceDate(),model.get(i).getCustomerName(),model.get(i).getInvoiceTotal()});}

    }//GEN-LAST:event_formWindowOpened

    public void loadFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadFileActionPerformed
        //Load the chosen file into the model
        JFileChooser choosef = new JFileChooser();
        int choosenfile = choosef.showOpenDialog(view);

        if (choosenfile == JFileChooser.APPROVE_OPTION)
        {
            String path = choosef.getSelectedFile().getPath();
        try
        {
            model = FileOps.loadFile(path);
        }
        catch (Exception e) {
            if (e.getMessage().equals("Wrong Date Format"))
            {
                JOptionPane.showMessageDialog(view,"Wrong Date Format\n Please Choose another File ","ERROR",JOptionPane.ERROR_MESSAGE);
            }
            else if(e.getClass() == FileNotFoundException.class)
            {
                JOptionPane.showMessageDialog(view,"File Not Found\n Please make sure file exists in project directory ","ERROR",JOptionPane.ERROR_MESSAGE);

            }
            else {
                JOptionPane.showMessageDialog(view,"File Format is not Supported\n Please Choose another File ","ERROR",JOptionPane.ERROR_MESSAGE);
            }
        }

            //update the table view
            DefaultTableModel table = new DefaultTableModel();
            view.InvTab.setModel(table);
            table.setColumnIdentifiers(new String [] {
                    "No.", "Date", "Customer", "Total"
            });
            for(int i = 0;i < model.size();i++)
            {
                table.addRow(new String[]{model.get(i).getInvoiceNum(),
                    model.get(i).getInvoiceDate(),model.get(i).getCustomerName(),model.get(i).getInvoiceTotal()});
            }
        }




    }//GEN-LAST:event_loadFileActionPerformed
    public void saveFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveFileActionPerformed
        //TODO add your handling code here:
        //update our model from the table view before saving
        //DefaultTableModel table1 = (DefaultTableModel)view.InvTab.getModel();


        try
        {
            FileOps.saveFile(model);
            JOptionPane.showMessageDialog(view,"File Saved Successfully ","Success",JOptionPane.INFORMATION_MESSAGE);

        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(view,"Something went wrong, try saving again","Error",JOptionPane.ERROR_MESSAGE);

        }

    }//GEN-LAST:event_saveFileActionPerformed

    public void createNewInvoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createNewInvoiceActionPerformed
        createInvoice();

    }//GEN-LAST:event_createNewInvoiceActionPerformed

    public void deleteInvoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteInvoiceActionPerformed
        deleteInvoice();
    }//GEN-LAST:event_deleteInvoiceActionPerformed

    public void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed
        saveChanges();
    }//GEN-LAST:event_saveBtnActionPerformed

    public void cancelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelBtnActionPerformed
        cancelChanges();
    }//GEN-LAST:event_cancelBtnActionPerformed

    public void InvTabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InvTabMouseClicked
        LoadDetails();
    }//GEN-LAST:event_InvTabMouseClicked

    public void InvTabPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_InvTabPropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_InvTabPropertyChange

    public void InvDetailsFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_InvDetailsFocusLost
//        DefaultTableModel Detailmodel = (DefaultTableModel)InvDetails.getModel();
//        Detailmodel.setValueAt(evt, ERROR, NORMAL);
    }//GEN-LAST:event_InvDetailsFocusLost

    public void InvDetailsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InvDetailsMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_InvDetailsMouseClicked

    public void InvoiceDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InvoiceDateActionPerformed

    }//GEN-LAST:event_InvoiceDateActionPerformed

    public void InvoiceDateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_InvoiceDateFocusLost
        if(view.InvoiceDate.getText().isEmpty()){}
        else{
            String regex = "^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[012])-(20[0-9]{2})$";
            if(!(view.InvoiceDate.getText().matches(regex))) {
                JOptionPane.showMessageDialog(view,"Wrong Date Format\n Please Enter Date as DD-MM-YYYY ","ERROR",JOptionPane.ERROR_MESSAGE);
                view.InvoiceDate.setText("");

            }
        }

    }//GEN-LAST:event_InvoiceDateFocusLost


}
